#define start 1
#define line_follower 2
#define tunnel 3
#define obstacle 4
#define bump 5
#define parking 6
#define flag 7
#define testing 8

unsigned int ADC_Read(void);

void start_area();
void line_area(unsigned char left_sensor, unsigned char right_sensor, unsigned int ldr_value);
void obstacle_area(unsigned char left_sensor, unsigned char right_sensor, unsigned char left_ir);
void bump_area(unsigned char left_sensor, unsigned char right_sensor, unsigned char left_ir);
void parking_area(unsigned char left_sensor, unsigned char right_sensor);
void servo_write_us(unsigned int us);
void seedna_mab9oo6_mennak();
void test();
void interrupt();
void delay_us_var(unsigned int us);


void delay_ms(unsigned int ms);
void Timer1_Init(void);
unsigned int ultrasonic_read_cm_front(void);
unsigned int ultrasonic_read_cm_right(void);

unsigned char obstacle_first_time = 1;
unsigned char inTunnel = 0;
unsigned int tunnel_in  = 300;
unsigned int tunnel_out = 200;
unsigned char mode;

volatile unsigned char started = 0;
volatile unsigned char arming = 0;
volatile unsigned int start_ms = 0;
volatile unsigned char buz_enable = 0;
volatile unsigned int buz_cnt = 0;

unsigned char btn_latched = 0;

void main()
{
    unsigned char left_sensor, right_sensor, left_ir;
    unsigned int ldr_value;

    TRISA = 0x01;
    TRISB = 0x41;   // RB0 input (button)    RB6 (left_ir)
    TRISC = 0x80;
    TRISD = 0xEC;   // RD0 output (LED), RD2/RD3 inputs (line), others as you had

    PORTB = 0x00;
    PORTC = 0x00;
    PORTD = 0x00;

    PR2  = 99;
    T2CON = 0b00000101;

    CCP1CON = 0b00001100;
    CCP2CON = 0b00001100;

    OPTION_REG = 0xC7;   // prescaler 1:256 on TMR0 (PSA=0, PS=111)
    TMR0 = 248;

    delay_ms(50);
    INTCON &= 0xF9;      // clear INTF and T0IF
    INTCON = 0xA0;       // GIE + T0IE only (NO RB0 interrupt)

    ADCON1 = 0xCE;
    ADCON0 = 0x41;

    Timer1_Init();

    mode = start;

    while(1)
    {


        left_ir = (PORTB & 0x40) ? 1 : 0;
        left_sensor  = (PORTD & 0x04) ? 1 : 0;
        right_sensor = (PORTD & 0x08) ? 1 : 0;

        ldr_value = ADC_Read();

        if(mode == testing)
            test();

        if(mode == start)
        {
            start_area();
        }
        else if(mode == line_follower)
        {
            line_area(left_sensor, right_sensor, ldr_value);
        }
        else if(mode == obstacle)
        {
            obstacle_area(left_sensor, right_sensor, left_ir);
        }
        else if(mode == bump)
        {
            bump_area(left_sensor, right_sensor, left_ir);
        }
        else if(mode == parking)
        {
            parking_area(left_sensor, right_sensor);
        }
        else if(mode == flag)
        {
            seedna_mab9oo6_mennak();
        }
    }
}

void start_area()
{
     while ((PORTB & 0x01))
    {

    }
    delay_ms(3000);
    PORTD = PORTD | 0x01;
    mode = line_follower;
}

void line_area(unsigned char left_sensor, unsigned char right_sensor, unsigned int ldr_value)
{

    if(!inTunnel && ldr_value > tunnel_in)
    {
        inTunnel = 1;
        PORTD |= 0x02;
    }
    else if(inTunnel && ldr_value < tunnel_out)
    {
        inTunnel = 0;
        PORTD &= 0xFD;
        mode = obstacle;
        return;
    }

    if(inTunnel)
{

    if(left_sensor == 1 && right_sensor == 1) { CCPR1L = 70; CCPR2L = 81; }
    else if(left_sensor == 0 && right_sensor == 1) { CCPR1L = 80; CCPR2L = 35; }
    else if(left_sensor == 1 && right_sensor == 0) { CCPR1L = 35; CCPR2L = 80; }
    return;
}

    PORTB = (PORTB & 0xE1) | 0x0A;

    if(left_sensor == 1 && right_sensor == 1)
    {
        CCPR1L = 50;
        CCPR2L = 66;
    }
    else if(left_sensor == 0 && right_sensor == 1)
    {
        CCPR1L = 70;
        CCPR2L = 35;
    }
    else if(left_sensor == 1 && right_sensor == 0)
    {
        CCPR1L = 35;
        CCPR2L = 70;
    }
    else
    {
        PORTB = (PORTB & 0xE1) | 0x00;
        CCPR1L = 0;
        CCPR2L = 0;
        delay_ms(100);

        PORTB = (PORTB & 0xE1) | 0x12;
        CCPR1L = 55;
        CCPR2L = 66;
        delay_ms(300);

        PORTB = (PORTB & 0xE1) | 0x0A;
        CCPR1L = 55;
        CCPR2L = 66;
        delay_ms(200);
    }
}

void obstacle_area(unsigned char left_sensor, unsigned char right_sensor, unsigned char left_ir)
{
    unsigned int d1,d2;

    PORTB = (PORTB & 0xE1) | 0x0A;

    d1 = ultrasonic_read_cm_front();
    d2 = ultrasonic_read_cm_right();
    if(left_ir == 0){
        CCPR1L = 25;
        CCPR2L = 60;
        delay_ms(500);
        return;
    }
    if(left_sensor == 1 && right_sensor == 1){
        if (d1 == 400 || d2 == 400){
        PORTB = (PORTB & 0xE1) | 0x14;         //reverse
        CCPR1L = 80;
        CCPR2L = 80;
        delay_ms(300);
        return;
        }
        if((d1 < 5))
        {
        // reverse
        PORTB = (PORTB & 0xE1) | 0x14;
        CCPR1L = 70;
        CCPR2L = 70;
        delay_ms(300);

        // escape turn (right)
        PORTB = (PORTB & 0xE1) | 0x0A;
        CCPR1L = 0;
        CCPR2L = 70;
        delay_ms(250);

        return;
        }

        if((d1 > 25)&&(d2 > 25))
        {
        CCPR1L = 60;         //forward
        CCPR2L = 61;
        }
        else if((d1 < 25 )&&(d2 > 25))
        {
        CCPR1L = 0;
        CCPR2L = 60;
        delay_ms(120);        //turn right
        }
        else if(((d1< 30 )&&(d2< 30)))
        {
       PORTB = (PORTB & 0xE1) | 0x14;      //reverse
       CCPR1L = 80;
       CCPR2L = 80;
       delay_ms(200);
       PORTB = (PORTB & 0xE1) | 0x0A;     // turn left
       CCPR1L = 70;
       CCPR2L = 25;
       delay_ms(120);
           return;
       }
       else
       {
        CCPR1L = 50;       //forward
        CCPR2L = 61;
        }

   }
   else{
        mode = bump;
   }

}


void bump_area(unsigned char left_sensor, unsigned char right_sensor, unsigned char left_ir){

PORTB = (PORTB & 0xE1) | 0x0A;

    if(left_ir == 0){
        CCPR1L = 15;
        CCPR2L = 80;
        return;
    }

    if(left_sensor == 1 && right_sensor == 1)
    {
        CCPR1L = 50;
        CCPR2L = 66;
    }
    else if(left_sensor == 0 && right_sensor == 1)
    {

        CCPR1L = 80;
        CCPR2L = 35;
    }
    else if(left_sensor == 1 && right_sensor == 0)
    {

        CCPR1L = 35;
        CCPR2L = 80;
    }
    else
    {
          CCPR1L = 55;
          CCPR2L = 66;
          mode = parking;
    }
}

void parking_area(unsigned char left_sensor, unsigned char right_sensor)
{
    static unsigned char step = 0;
    static unsigned int t = 0;
    unsigned char wall = 0;
     wall = ultrasonic_read_cm_front();
    if(step == 0)
    {
        buz_enable = 1;   // start buzzer
        t = 0;
        step = 1;
    }

    if(step == 1)
    {
        // park right
     if (wall > 20){
         PORTB = (PORTB & 0xE1) | 0x0A;        //forward
         CCPR1L = 49;
         CCPR2L = 60;
     }
     else{
        CCPR1L = 0;        //turn right
        CCPR2L = 70;
        delay_ms(500);
        step = 2;
     }

    }
    else if(step == 2)
    {
        PORTB = (PORTB & 0xE1) | 0x00;
        CCPR1L = 0;
        CCPR2L = 0;

        buz_enable = 0;
        mode = flag;
        return;


    }
}


void seedna_mab9oo6_mennak()
{
    static unsigned char done = 0;
    unsigned int i;

    // stop motors
    PORTB = (PORTB & 0xE1) | 0x00;
    CCPR1L = 0;
    CCPR2L = 0;

    if(!done)
    {
        for(i = 0; i < 50; i++)          // ~1 second
            servo_write_us(2000);        // raise flag

        done = 1;
    }

    // keep holding servo up
    servo_write_us(2000);
}


void Timer1_Init(void)
{
    T1CON = 0x10;
    TMR1H = 0;
    TMR1L = 0;
}

void test()
{
    PORTB = (PORTB & 0xE1) | 0x0A;        //forward
    CCPR1L = 49;
    CCPR2L = 60;
    delay_ms(1000);

    PORTB = (PORTB & 0xE1) | 0x14;         //backward
    CCPR1L = 49;
    CCPR2L = 60;
    delay_ms(1000);

    PORTB = (PORTB & 0xE1) | 0x12;                 //left
    CCPR1L = 49;
    CCPR2L = 60;
    delay_ms(1000);

    PORTB = (PORTB & 0xE1) | 0x0C;                    //right
    CCPR1L = 49;
    CCPR2L = 60;
    delay_ms(1000);

    PORTB = (PORTB & 0xE1) | 0x00;
    CCPR1L = 0;
    CCPR2L = 0;

    while(1);
}

unsigned int ultrasonic_read_cm_front(void)
{
    unsigned int t;
    unsigned int dist;
    unsigned int timeout;

    PORTD |= 0x10;              //0001 0000
    delay_us_var(20);
    PORTD &= (~0x10);


    timeout = 0;
    while(!(PORTD & 0x20)) {         //0010 0000
        timeout++;
        if(timeout > 60000) return 400;
    }

    TMR1H = 0;
    TMR1L = 0;
    T1CON |= 0x01;

    timeout = 0;
    while(PORTD & 0x20) {
        timeout++;
        if(timeout > 60000) break;
    }

    T1CON &= 0xFE;

    t = ((unsigned int)TMR1H << 8) | TMR1L;

    dist = t / 58;
    if(dist == 0) dist = 1;
    return dist;
}

unsigned int ultrasonic_read_cm_right(void)
{
    unsigned int t;
    unsigned int dist;
    unsigned int timeout;

    PORTC |= 0x40;            //0100 0000
    delay_us_var(20);
    PORTC &= (~0x40);


    timeout = 0;
    while(!(PORTC & 0x80)) {         //1000 0000
        timeout++;
        if(timeout > 60000) return 400;
    }

    TMR1H = 0;
    TMR1L = 0;
    T1CON |= 0x01;

    timeout = 0;
    while(PORTC & 0x80) {
        timeout++;
        if(timeout > 60000) break;
    }

    T1CON &= 0xFE;

    t = ((unsigned int)TMR1H << 8) | TMR1L;

    dist = t / 58;
    if(dist == 0) dist = 1;
    return dist;
}

void delay_ms(unsigned int ms)
{
    unsigned int i, j;
    for(i = 0; i < ms; i++)
        for(j = 0; j < 333; j++);
}

void delay_us_var(unsigned int us)
{
    unsigned int i;
    while(us--)
    {
        for(i = 0; i < 3; i++);   // adjust for your clock
    }
}


void servo_write_us(unsigned int us)
{
    unsigned int rest;

    PORTB |= 0x20;                      // RB5 HIGH
    delay_us_var(us);                   // <-- variable delay OK
    PORTB &= (unsigned char)~0x20;      // RB5 LOW

    rest = 20000 - us;

    while(rest >= 1000) {
        delay_ms(1);
        rest -= 1000;
    }
    if(rest)
        delay_us_var(rest);
}


unsigned int ADC_Read(void)
{
    ADCON0 |= 0x04;
    while(ADCON0 & 0x04);
    return ((ADRESH << 8) | ADRESL);
}

void interrupt()
{
    if(INTCON & 0x04)   // T0IF
    {
        TMR0 = 248;

        if(buz_enable)
        {
            buz_cnt++;
            if(buz_cnt >= 1000)
            {
                buz_cnt = 0;
                PORTD ^= 0x02;    // toggle RD1 (parking beeps)
            }
        }
        // else: DO NOTHING to RD1 (don't clear it here)

        INTCON &= 0xFB;
    }
}
